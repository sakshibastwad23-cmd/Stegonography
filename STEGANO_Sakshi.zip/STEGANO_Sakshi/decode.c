#include <stdio.h>
#include <string.h>
#include "decode.h"
#include "types.h"


/* Function Definitions */


/* Step 1: Read and validate decode arguments */

Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    /* Check stego image */
    if (argv[2] != NULL && strstr(argv[2], ".bmp") != NULL)
    {
        decInfo->stego_image_fname = argv[2];
    }
    else
    {
        printf("ERROR: Stego image must be a .bmp file\n");
        return e_failure;
    }


    /* Check output file name */
    if (argv[3] != NULL)
    {
        decInfo->output_fname = argv[3];
    }
    else
    {
        decInfo->output_fname = "output";
    }


    return e_success;
}


/* Step 2: Open stego image */

Status open_decode_files(DecodeInfo *decInfo)
{
    /* Open stego image in read mode */
    decInfo->fptr_stego_image =
        fopen(decInfo->stego_image_fname, "rb");

    if (decInfo->fptr_stego_image == NULL)
    {
        perror("fopen");

        printf("ERROR: Unable to open stego image %s\n",
               decInfo->stego_image_fname);

        return e_failure;
    }


    return e_success;
}


/* Step 3: Decode magic string */

Status decode_magic_string(const char *magic_string,
                           DecodeInfo *decInfo)
{
    char image_buffer[8];
    char decoded_char;

    for (int i = 0; magic_string[i] != '\0'; i++)
    {
        /* Read 8 bytes from stego image */
        if (fread(image_buffer,
                  sizeof(char),
                  8,
                  decInfo->fptr_stego_image) != 8)
        {
            printf("ERROR: Unable to read image data\n");
            return e_failure;
        }


        /* Decode one character */
        if (decode_byte_from_lsb(image_buffer,
                                 &decoded_char) == e_failure)
        {
            printf("ERROR: Unable to decode magic string\n");
            return e_failure;
        }


        /* Compare decoded character */
        if (decoded_char != magic_string[i])
        {
            printf("ERROR: Magic string mismatch\n");
            return e_failure;
        }
    }


    return e_success;
}


/* Step 4: Decode secret file extension size */

Status decode_secret_file_extn_size(int *size,
                                    DecodeInfo *decInfo)
{
    char buffer[32];


    /* Read 32 bytes */
    if (fread(buffer,
              sizeof(char),
              32,
              decInfo->fptr_stego_image) != 32)
    {
        printf("ERROR: Unable to read image data\n");
        return e_failure;
    }


    /* Decode size */
    if (decode_size_from_lsb(buffer, size) == e_failure)
    {
        printf("ERROR: Unable to decode extension size\n");
        return e_failure;
    }


    return e_success;
}


/* Step 5: Decode secret file extension */

Status decode_secret_file_extn(int size,
                               DecodeInfo *decInfo)
{
    char buffer[8];
    char decoded_char;


    for (int i = 0; i < size; i++)
    {
        /* Read 8 bytes */
        if (fread(buffer,
                  sizeof(char),
                  8,
                  decInfo->fptr_stego_image) != 8)
        {
            printf("ERROR: Unable to read image data\n");
            return e_failure;
        }


        /* Decode character */
        if (decode_byte_from_lsb(buffer,
                                 &decoded_char) == e_failure)
        {
            printf("ERROR: Unable to decode extension\n");
            return e_failure;
        }


        decInfo->extn_secret_file[i] = decoded_char;
    }


    /* Add NULL character */
    decInfo->extn_secret_file[size] = '\0';


    return e_success;
}


/* Step 6: Decode secret file size */

Status decode_secret_file_size(long *file_size,
                               DecodeInfo *decInfo)
{
    char buffer[32];
    int size;


    /* Read 32 bytes */
    if (fread(buffer,
              sizeof(char),
              32,
              decInfo->fptr_stego_image) != 32)
    {
        printf("ERROR: Unable to read image data\n");
        return e_failure;
    }


    /* Decode size */
    if (decode_size_from_lsb(buffer, &size) == e_failure)
    {
        printf("ERROR: Unable to decode secret file size\n");
        return e_failure;
    }


    *file_size = size;


    return e_success;
}


/* Step 7: Decode secret file data */

Status decode_secret_file_data(long file_size,
                               DecodeInfo *decInfo)
{
    char buffer[8];
    char decoded_char;


    for (long i = 0; i < file_size; i++)
    {
        /* Read 8 bytes from stego image */
        if (fread(buffer,
                  sizeof(char),
                  8,
                  decInfo->fptr_stego_image) != 8)
        {
            printf("ERROR: Unable to read image data\n");
            return e_failure;
        }


        /* Decode one character */
        if (decode_byte_from_lsb(buffer,
                                 &decoded_char) == e_failure)
        {
            printf("ERROR: Unable to decode secret data\n");
            return e_failure;
        }


        /* Write decoded character */
        if (fwrite(&decoded_char,
                   sizeof(char),
                   1,
                   decInfo->fptr_output) != 1)
        {
            printf("ERROR: Unable to write output data\n");
            return e_failure;
        }
    }


    return e_success;
}


/* Decode one byte from LSB */

Status decode_byte_from_lsb(char *image_buffer,
                            char *data)
{
    char ch = 0;


    for (int i = 0; i < 8; i++)
    {
        /*
         * Get LSB of each image byte
         * and form one character
         */
        ch = ch |
             ((image_buffer[i] & 1) << (7 - i));
    }


    *data = ch;


    return e_success;
}


/* Decode 32-bit size from LSB */

Status decode_size_from_lsb(char *image_buffer,
                            int *size)
{
    int value = 0;


    for (int i = 0; i < 32; i++)
    {
        /*
         * Extract LSB from image byte
         */
        value = value |
                ((image_buffer[i] & 1) << (31 - i));
    }


    *size = value;


    return e_success;
}


/* Main decoding function */

Status do_decoding(DecodeInfo *decInfo)
{
    int extn_size;
    long secret_file_size;
    char output_filename[100];


    /* Step 1: Open stego image */

    if (open_decode_files(decInfo) == e_success)
    {
        printf("INFO: Stego image opened successfully\n");
    }
    else
    {
        printf("ERROR: Unable to open stego image\n");
        return e_failure;
    }


    /*
     * Step 2:
     * Skip BMP header
     *
     * BMP header = 54 bytes
     */
    fseek(decInfo->fptr_stego_image,
          54,
          SEEK_SET);


    /* Step 3: Decode magic string */

    if (decode_magic_string(MAGIC_STRING,
                            decInfo) == e_success)
    {
        printf("INFO: Magic string decoded successfully\n");
    }
    else
    {
        printf("ERROR: Magic string decoding failed\n");

        fclose(decInfo->fptr_stego_image);

        return e_failure;
    }


    /* Step 4: Decode extension size */

    if (decode_secret_file_extn_size(&extn_size,
                                     decInfo) == e_success)
    {
        printf("INFO: Secret file extension size decoded successfully\n");

        printf("INFO: Extension size = %d\n",
               extn_size);
    }
    else
    {
        printf("ERROR: Unable to decode extension size\n");

        fclose(decInfo->fptr_stego_image);

        return e_failure;
    }


    /* Step 5: Decode extension */

    if (decode_secret_file_extn(extn_size,
                                decInfo) == e_success)
    {
        printf("INFO: Secret file extension decoded successfully\n");

        printf("INFO: Extension = %s\n",
               decInfo->extn_secret_file);
    }
    else
    {
        printf("ERROR: Unable to decode extension\n");

        fclose(decInfo->fptr_stego_image);

        return e_failure;
    }


    /*
     * Step 6:
     * Merge output file name and extension
     *
     * output + .txt
     *       ↓
     * output.txt
     */

    strcpy(output_filename,
           decInfo->output_fname);

    strcat(output_filename,
           decInfo->extn_secret_file);


    printf("INFO: Output file = %s\n",
           output_filename);


    /* Open output file in write mode */

    decInfo->fptr_output =
        fopen(output_filename, "wb");

    if (decInfo->fptr_output == NULL)
    {
        perror("fopen");

        printf("ERROR: Unable to create output file\n");

        fclose(decInfo->fptr_stego_image);

        return e_failure;
    }


    /* Step 7: Decode secret file size */

    if (decode_secret_file_size(&secret_file_size,
                                decInfo) == e_success)
    {
        printf("INFO: Secret file size decoded successfully\n");

        printf("INFO: Secret file size = %ld bytes\n",
               secret_file_size);
    }
    else
    {
        printf("ERROR: Unable to decode secret file size\n");

        fclose(decInfo->fptr_stego_image);
        fclose(decInfo->fptr_output);

        return e_failure;
    }


    /* Step 8: Decode secret file data */

    if (decode_secret_file_data(secret_file_size,
                                decInfo) == e_success)
    {
        printf("INFO: Secret file data decoded successfully\n");
    }
    else
    {
        printf("ERROR: Unable to decode secret file data\n");

        fclose(decInfo->fptr_stego_image);
        fclose(decInfo->fptr_output);

        return e_failure;
    }


    /* Step 9: Close files */

    fclose(decInfo->fptr_stego_image);
    fclose(decInfo->fptr_output);


    printf("INFO: Decoding completed successfully\n");


    return e_success;
}