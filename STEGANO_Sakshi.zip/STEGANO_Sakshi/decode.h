#ifndef DECODE_H
#define DECODE_H

#include <stdio.h>
#include "types.h"

#define MAGIC_STRING "#*"

typedef struct _DecodeInfo
{
    char *stego_image_fname;
    FILE *fptr_stego_image;

    char *output_fname;
    FILE *fptr_output;

    char extn_secret_file[20];

} DecodeInfo;


Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

Status open_decode_files(DecodeInfo *decInfo);

Status decode_magic_string(const char *magic_string,
                           DecodeInfo *decInfo);

Status decode_secret_file_extn_size(int *size,
                                    DecodeInfo *decInfo);

Status decode_secret_file_extn(int size,
                               DecodeInfo *decInfo);

Status decode_secret_file_size(long *file_size,
                               DecodeInfo *decInfo);

Status decode_secret_file_data(long file_size,
                               DecodeInfo *decInfo);

Status decode_byte_from_lsb(char *image_buffer,
                            char *data);

Status decode_size_from_lsb(char *image_buffer,
                            int *size);

Status do_decoding(DecodeInfo *decInfo);

#endif