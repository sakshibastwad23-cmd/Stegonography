#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

OperationType check_operation_type(char *);

int main(int argc, char *argv[])
{
    /* Check command line arguments */
    if (argc < 3)
    {
        printf("Usage: %s -e <source.bmp> <secret.txt> [stego.bmp]\n",
               argv[0]);
        return 1;
    }

    /* Step 1: Check operation type */
    OperationType operation = check_operation_type(argv[1]);

    if (operation == e_encode)
    {
        /* Create EncodeInfo structure */
        EncodeInfo encInfo;

        /* Step 2: Read and validate encode arguments */
        if (read_and_validate_encode_args(argv, &encInfo) == e_success)
        {
            printf("INFO: Encoding arguments validated successfully\n");

            /* Step 3: Perform encoding */
            if (do_encoding(&encInfo) == e_success)
            {
                printf("INFO: Encoding successful\n");
            }
            else
            {
                printf("ERROR: Encoding failed\n");
                return 1;
            }
        }
        else
        {
            printf("ERROR: Encoding arguments validation failed\n");
            return 1;
        }
    }

    /* Decoding */
    else if (operation == e_decode)
    {
        DecodeInfo decInfo;

        if (read_and_validate_decode_args(argv, &decInfo) == e_success)
        {
            printf("INFO: Decoding arguments validated successfully\n");

            if (do_decoding(&decInfo) == e_success)
            {
                printf("INFO: Decoding successful\n");
            }
            else
            {
                printf("ERROR: Decoding failed\n");
                return 1;
            }
        }
        else
        {
            printf("ERROR: Decoding arguments validation failed\n");
            return 1;
        }
    }

    else
    {
        printf("ERROR: Unsupported operation\n");
        return 1;
    }

    return 0;
}


OperationType check_operation_type(char *symbol)
{
    /* Check for encode */
    if (strcmp(symbol, "-e") == 0)
    {
        return e_encode;
    }


    /* Check for decode */
    if (strcmp(symbol, "-d") == 0)
    {
        return e_decode;
    }


    /* Unsupported operation */
    return e_unsupported;
}