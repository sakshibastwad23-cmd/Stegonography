#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"

/* Function Definitions */

/*
 * Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel
 *         (3 bytes per pixel for 24-bit BMP)
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;

    /* Seek to 18th byte */
    fseek(fptr_image, 18, SEEK_SET);

    /* Read width */
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    /* Read height */
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    /* Return image capacity */
    return width * height * 3;
}


/* Get secret file size */
uint get_file_size(FILE *fptr)
{
    long int size;

    fseek(fptr, 0, SEEK_END);

    size = ftell(fptr);

    rewind(fptr);

    return size;
}


/*
 * Validate command line arguments
 */

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    /* Step 1: Check source image */
    if (argv[2] != NULL && strstr(argv[2], ".bmp") != NULL)
    {
        encInfo->src_image_fname = argv[2];
    }
    else
    {
        printf("ERROR: Source image must be a .bmp file\n");
        return e_failure;
    }

    /* Step 2: Check secret file */
    if (argv[3] != NULL)
    {
        char *ext = strrchr(argv[3], '.');

        if (ext != NULL && ext[1] != '\0')
        {
            encInfo->secret_fname = argv[3];

            strcpy(encInfo->extn_secret_file, ext);

            printf("INFO: Secret file = %s\n", encInfo->secret_fname);
            printf("INFO: Extension = %s\n", encInfo->extn_secret_file);
        }
        else
        {
            printf("ERROR: Secret file must have an extension\n");
            return e_failure;
        }
    }
    else
    {
        printf("ERROR: Secret file is missing\n");
        return e_failure;
    }

    /* Step 3: Check output file */
    if (argv[4] != NULL)
    {
        if (strstr(argv[4], ".bmp") != NULL)
        {
            encInfo->stego_image_fname = argv[4];
        }
        else
        {
            printf("ERROR: Output image must be a .bmp file\n");
            return e_failure;
        }
    }
    else
    {
        encInfo->stego_image_fname = "stego.bmp";
    }

    return e_success;
}


/*
 * Open source image, secret file and stego image
 */
Status open_files(EncodeInfo *encInfo)
{
    /* Source image */
    encInfo->fptr_src_image =
        fopen(encInfo->src_image_fname, "rb");

    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr,
                "ERROR: Unable to open file %s\n",
                encInfo->src_image_fname);

        return e_failure;
    }


    /* Secret file */
    encInfo->fptr_secret =
        fopen(encInfo->secret_fname, "rb");

    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr,
                "ERROR: Unable to open file %s\n",
                encInfo->secret_fname);

        return e_failure;
    }


    /* Stego image */
    encInfo->fptr_stego_image =
        fopen(encInfo->stego_image_fname, "wb");

    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr,
                "ERROR: Unable to open file %s\n",
                encInfo->stego_image_fname);

        return e_failure;
    }

    return e_success;
}


/*
 * Check whether image has enough capacity
 */
Status check_capacity(EncodeInfo *encInfo)
{
    encInfo->image_capacity =
        get_image_size_for_bmp(encInfo->fptr_src_image);

    encInfo->size_secret_file =
        get_file_size(encInfo->fptr_secret);


    if (encInfo->image_capacity >=
        (16 +
         32 +
         (strlen(encInfo->extn_secret_file) * 8) +
         32 +
         (encInfo->size_secret_file * 8)))
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}


/*
 * Copy BMP header
 */
Status copy_bmp_header(FILE *fptr_src_image,
                       FILE *fptr_dest_image)
{
    char header[54];

    rewind(fptr_src_image);

    if (fread(header, sizeof(char), 54, fptr_src_image) != 54)
    {
        printf("ERROR: Unable to read BMP header\n");
        return e_failure;
    }


    if (fwrite(header, sizeof(char), 54, fptr_dest_image) != 54)
    {
        printf("ERROR: Unable to write BMP header\n");
        return e_failure;
    }

    return e_success;
}


/*
 * Encode magic string
 */
Status encode_magic_string(const char *magic_string,
                           EncodeInfo *encInfo)
{
    char image_buffer[8];

    for (int i = 0; magic_string[i] != '\0'; i++)
    {
        if (fread(image_buffer,
                  sizeof(char),
                  8,
                  encInfo->fptr_src_image) != 8)
        {
            printf("ERROR: Unable to read image data\n");
            return e_failure;
        }


        if (encode_byte_to_lsb(magic_string[i],
                                image_buffer) == e_failure)
        {
            printf("ERROR: Unable to encode magic string\n");
            return e_failure;
        }


        if (fwrite(image_buffer,
                   sizeof(char),
                   8,
                   encInfo->fptr_stego_image) != 8)
        {
            printf("ERROR: Unable to write image data\n");
            return e_failure;
        }
    }

    return e_success;
}


/*
 * Encode secret file extension size
 */
Status encode_secret_file_extn_size(int size,
                                    EncodeInfo *encInfo)
{
    char buffer[32];

    if (fread(buffer,
              sizeof(char),
              32,
              encInfo->fptr_src_image) != 32)
    {
        printf("ERROR: Unable to read image data\n");
        return e_failure;
    }


    if (encode_size_to_lsb(size, buffer) == e_failure)
    {
        printf("ERROR: Unable to encode extension size\n");
        return e_failure;
    }


    if (fwrite(buffer,
                sizeof(char),
                32,
                encInfo->fptr_stego_image) != 32)
    {
        printf("ERROR: Unable to write image data\n");
        return e_failure;
    }

    return e_success;
}


/*
 * Encode secret file extension
 */
Status encode_secret_file_extn(const char *file_extn,
                               EncodeInfo *encInfo)
{
    char buffer[8];

    for (int i = 0; file_extn[i] != '\0'; i++)
    {
        if (fread(buffer,
                  sizeof(char),
                  8,
                  encInfo->fptr_src_image) != 8)
        {
            printf("ERROR: Unable to read image data\n");
            return e_failure;
        }


        if (encode_byte_to_lsb(file_extn[i],
                               buffer) == e_failure)
        {
            printf("ERROR: Unable to encode secret file extension\n");
            return e_failure;
        }


        if (fwrite(buffer,
                   sizeof(char),
                   8,
                   encInfo->fptr_stego_image) != 8)
        {
            printf("ERROR: Unable to write image data\n");
            return e_failure;
        }
    }

    return e_success;
}


/*
 * Encode secret file size
 */
Status encode_secret_file_size(long file_size,
                               EncodeInfo *encInfo)
{
    char buffer[32];

    if (fread(buffer,
              sizeof(char),
              32,
              encInfo->fptr_src_image) != 32)
    {
        printf("ERROR: Unable to read image data\n");
        return e_failure;
    }


    if (encode_size_to_lsb((int)file_size, buffer) == e_failure)
    {
        printf("ERROR: Unable to encode secret file size\n");
        return e_failure;
    }


    if (fwrite(buffer,
                sizeof(char),
                32,
                encInfo->fptr_stego_image) != 32)
    {
        printf("ERROR: Unable to write image data\n");
        return e_failure;
    }

    return e_success;
}


/*
 * Encode secret file data
 */
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char data;
    char image_buffer[8];

    rewind(encInfo->fptr_secret);

    for (long i = 0;
         i < encInfo->size_secret_file;
         i++)
    {
        /* Read one byte from secret file */
        if (fread(&data,
                  sizeof(char),
                  1,
                  encInfo->fptr_secret) != 1)
        {
            printf("ERROR: Unable to read secret file data\n");
            return e_failure;
        }


        /* Read 8 bytes from image */
        if (fread(image_buffer,
                  sizeof(char),
                  8,
                  encInfo->fptr_src_image) != 8)
        {
            printf("ERROR: Unable to read image data\n");
            return e_failure;
        }


        /* Encode one secret byte into 8 image bytes */
        if (encode_byte_to_lsb(data,
                               image_buffer) == e_failure)
        {
            printf("ERROR: Unable to encode secret file data\n");
            return e_failure;
        }


        /* Write encoded image bytes */
        if (fwrite(image_buffer,
                   sizeof(char),
                   8,
                   encInfo->fptr_stego_image) != 8)
        {
            printf("ERROR: Unable to write encoded data\n");
            return e_failure;
        }
    }

    return e_success;
}


/*
 * Copy remaining image data
 */
Status copy_remaining_img_data(FILE *fptr_src,
                               FILE *fptr_dest)
{
    char buffer[1024];
    int bytes_read;

    while ((bytes_read =
            fread(buffer,
                  sizeof(char),
                  1024,
                  fptr_src)) > 0)
    {
        if (fwrite(buffer,
                   sizeof(char),
                   bytes_read,
                   fptr_dest) != bytes_read)
        {
            printf("ERROR: Unable to copy remaining image data\n");
            return e_failure;
        }
    }

    return e_success;
}


/*
 * Encode one byte into 8 image bytes
 */
Status encode_byte_to_lsb(char data,
                          char *image_buffer)
{
    int i;

    for (i = 0; i < 8; i++)
    {
        /* Clear LSB */
        image_buffer[i] =
            image_buffer[i] & ~1;

        /* Set LSB with secret bit */
        image_buffer[i] =
            image_buffer[i] |
            ((data >> (7 - i)) & 1);
    }

    return e_success;
}


/*
 * Encode 32-bit integer into 32 image bytes
 */
Status encode_size_to_lsb(int size,
                          char *imageBuffer)
{
    int i;

    for (i = 0; i < 32; i++)
    {
        /* Clear LSB */
        imageBuffer[i] =
            imageBuffer[i] & ~1;

        /* Set LSB with size bit */
        imageBuffer[i] =
            imageBuffer[i] |
            ((size >> (31 - i)) & 1);
    }

    return e_success;
}


/*
 * Main encoding function
 */
Status do_encoding(EncodeInfo *encInfo)
{
    /* Step 1: Open files */
    if (open_files(encInfo) == e_success)
    {
        printf("INFO: Opened all required files\n");
    }
    else
    {
        printf("ERROR: Unable to open required files\n");
        return e_failure;
    }


    /* Step 2: Check capacity */
    if (check_capacity(encInfo) == e_success)
    {
        printf("INFO: Image has enough capacity\n");
    }
    else
    {
        printf("ERROR: Image does not have enough capacity\n");
        return e_failure;
    }


    /* Step 3: Copy BMP header */
    if (copy_bmp_header(encInfo->fptr_src_image,
                        encInfo->fptr_stego_image) == e_success)
    {
        printf("INFO: BMP header copied successfully\n");
    }
    else
    {
        printf("ERROR: Unable to copy BMP header\n");
        return e_failure;
    }


    /* Step 4: Encode magic string */
    if (encode_magic_string(MAGIC_STRING,
                            encInfo) == e_success)
    {
        printf("INFO: Magic string encoded successfully\n");
    }
    else
    {
        printf("ERROR: Unable to encode magic string\n");
        return e_failure;
    }


    /* Step 5: Encode secret file extension size */
    if (encode_secret_file_extn_size(
            strlen(encInfo->extn_secret_file),
            encInfo) == e_success)
    {
        printf("INFO: Secret file extension size encoded successfully\n");
    }
    else
    {
        printf("ERROR: Unable to encode secret file extension size\n");
        return e_failure;
    }


    /* Step 6: Encode secret file extension */
    if (encode_secret_file_extn(
            encInfo->extn_secret_file,
            encInfo) == e_success)
    {
        printf("INFO: Secret file extension encoded successfully\n");
    }
    else
    {
        printf("ERROR: Unable to encode secret file extension\n");
        return e_failure;
    }


    /* Step 7: Encode secret file size */
    if (encode_secret_file_size(
            encInfo->size_secret_file,
            encInfo) == e_success)
    {
        printf("INFO: Secret file size encoded successfully\n");
    }
    else
    {
        printf("ERROR: Unable to encode secret file size\n");
        return e_failure;
    }


    /* Step 8: Encode secret file data */
    if (encode_secret_file_data(encInfo) == e_success)
    {
        printf("INFO: Secret file data encoded successfully\n");
    }
    else
    {
        printf("ERROR: Unable to encode secret file data\n");
        return e_failure;
    }


    /* Step 9: Copy remaining image data */
    if (copy_remaining_img_data(
            encInfo->fptr_src_image,
            encInfo->fptr_stego_image) == e_success)
    {
        printf("INFO: Remaining image data copied successfully\n");
    }
    else
    {
        printf("ERROR: Unable to copy remaining image data\n");
        return e_failure;
    }


    printf("INFO: Encoding completed successfully\n");

    return e_success;
}